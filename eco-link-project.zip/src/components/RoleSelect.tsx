import { Recycle, Smartphone, Building2, Leaf } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Button } from '@/components/ui/Button';

export function RoleSelect() {
  const { t, setRole } = useApp();

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 via-white to-cyan-50 flex flex-col items-center justify-center px-6 py-10">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-14 h-14 rounded-2xl bg-green-600 flex items-center justify-center shadow-lg">
          <Recycle className="w-8 h-8 text-white" strokeWidth={2.5} />
        </div>
        <h1 className="text-3xl font-bold text-gray-800 tracking-tight">
          {t('app_name')}
        </h1>
      </div>
      <p className="text-gray-500 text-sm mb-10 text-center max-w-xs">
        A digital bridge between informal e-waste collectors and authorized
        recyclers.
      </p>

      <div className="w-full max-w-sm space-y-4">
        <button
          onClick={() => setRole('collector')}
          className="w-full bg-white rounded-2xl p-5 shadow-sm border border-gray-100 hover:shadow-md hover:border-green-200 transition-all duration-200 active:scale-[0.98] text-left group"
        >
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-green-50 flex items-center justify-center group-hover:bg-green-100 transition-colors">
              <Smartphone className="w-7 h-7 text-green-600" strokeWidth={2} />
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-800">
                {t('collector_demo')}
              </h2>
              <p className="text-sm text-gray-500">Mobile-first interface</p>
            </div>
          </div>
        </button>

        <button
          onClick={() => setRole('recycler')}
          className="w-full bg-white rounded-2xl p-5 shadow-sm border border-gray-100 hover:shadow-md hover:border-cyan-200 transition-all duration-200 active:scale-[0.98] text-left group"
        >
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-cyan-50 flex items-center justify-center group-hover:bg-cyan-100 transition-colors">
              <Building2 className="w-7 h-7 text-cyan-600" strokeWidth={2} />
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-800">
                {t('recycler_demo')}
              </h2>
              <p className="text-sm text-gray-500">Desktop / tablet interface</p>
            </div>
          </div>
        </button>
      </div>

      <div className="mt-12 flex items-center gap-2 text-gray-400 text-xs">
        <Leaf className="w-4 h-4" />
        <span>SIH 2026 Hackathon MVP</span>
      </div>
    </div>
  );
}
