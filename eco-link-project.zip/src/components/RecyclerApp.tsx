import { useState } from 'react';
import { RecyclerSidebar, RecyclerMobileNav } from '@/components/recycler/RecyclerSidebar';
import { RecyclerDashboard } from '@/components/recycler/RecyclerDashboard';
import { IncomingLot } from '@/components/recycler/IncomingLot';
import { RecyclerLotDetail } from '@/components/recycler/RecyclerLotDetail';
import { RecyclerTransactions } from '@/components/recycler/RecyclerTransactions';
import { RecyclerProfile } from '@/components/recycler/RecyclerProfile';
import type { RecyclerScreen } from '@/types';

export function RecyclerApp() {
  const [screen, setScreen] = useState<RecyclerScreen>('dashboard');

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <RecyclerSidebar active={screen} onNavigate={setScreen} />
      <div className="flex-1 min-w-0 pb-20 md:pb-0">
        <header className="md:hidden sticky top-0 z-20 bg-white border-b border-gray-100 px-5 py-4">
          <span className="font-bold text-gray-800">ECO-LINK</span>
        </header>
        {screen === 'dashboard' && <RecyclerDashboard onNavigate={setScreen} />}
        {screen === 'incoming' && <IncomingLot onNavigate={setScreen} />}
        {screen === 'lotDetail' && <RecyclerLotDetail onSendOffer={() => setScreen('transactions')} onBack={() => setScreen('incoming')} />}
        {screen === 'transactions' && <RecyclerTransactions />}
        {screen === 'profile' && <RecyclerProfile />}
      </div>
      <RecyclerMobileNav active={screen} onNavigate={setScreen} />
    </div>
  );
}
