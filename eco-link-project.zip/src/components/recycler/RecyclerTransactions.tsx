import { Receipt, CheckCircle2, MapPin, CalendarDays } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { demoHandover } from '@/data/mockData';

export function RecyclerTransactions() {
  const { t } = useApp();
  return (
    <div className="p-5 lg:p-8 space-y-5 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold text-gray-800">{t('transactions')}</h1>
        <p className="text-sm text-gray-500 mt-1">Completed recycler transactions.</p>
      </div>
      <Card className="p-0 overflow-hidden">
        <div className="hidden sm:grid grid-cols-6 gap-3 px-5 py-3 bg-gray-50 text-xs font-semibold text-gray-400 uppercase">
          <span>Lot</span><span>Material</span><span>Weight</span><span>Amount</span><span>Status</span><span>Payment</span>
        </div>
        <div className="p-4 sm:px-5 flex flex-wrap sm:grid sm:grid-cols-6 gap-3 items-center">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-green-50 flex items-center justify-center"><Receipt className="w-4 h-4 text-green-600" /></div>
            <span className="font-bold text-gray-800">{demoHandover.lotId}</span>
          </div>
          <span className="text-sm text-gray-600">{demoHandover.material}</span>
          <span className="text-sm text-gray-600">{demoHandover.weightKg} kg</span>
          <span className="font-bold text-gray-800">₹{demoHandover.finalValue.toLocaleString('en-IN')}</span>
          <Badge variant="success"><CheckCircle2 className="w-3 h-3" /> {t('completed')}</Badge>
          <Badge variant="success">{demoHandover.paymentStatus}</Badge>
        </div>
      </Card>
    </div>
  );
}
