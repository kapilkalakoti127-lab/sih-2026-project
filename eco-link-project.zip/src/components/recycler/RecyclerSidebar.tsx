import { Recycle, LayoutDashboard, Inbox, Receipt, UserRound, LogOut } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import type { RecyclerScreen } from '@/types';

interface RecyclerSidebarProps {
  active: RecyclerScreen;
  onNavigate: (screen: RecyclerScreen) => void;
}

const items: { key: RecyclerScreen; icon: typeof LayoutDashboard; labelKey: string }[] = [
  { key: 'dashboard', icon: LayoutDashboard, labelKey: 'dashboard' },
  { key: 'incoming', icon: Inbox, labelKey: 'incoming_lot' },
  { key: 'transactions', icon: Receipt, labelKey: 'transactions' },
  { key: 'profile', icon: UserRound, labelKey: 'profile' },
];

export function RecyclerSidebar({ active, onNavigate }: RecyclerSidebarProps) {
  const { t, setRole } = useApp();

  return (
    <aside className="hidden md:flex w-64 shrink-0 bg-gray-900 min-h-screen flex-col text-white p-4">
      <div className="flex items-center gap-3 px-3 py-4 mb-6">
        <div className="w-10 h-10 rounded-xl bg-green-500 flex items-center justify-center">
          <Recycle className="w-6 h-6 text-white" strokeWidth={2.5} />
        </div>
        <span className="font-bold text-xl tracking-tight">{t('app_name')}</span>
      </div>

      <nav className="space-y-1 flex-1">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = active === item.key;
          return (
            <button
              key={item.key}
              onClick={() => onNavigate(item.key)}
              className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-medium transition-colors ${
                isActive
                  ? 'bg-green-600 text-white'
                  : 'text-gray-400 hover:bg-gray-800 hover:text-white'
              }`}
            >
              <Icon className="w-5 h-5" />
              {t(item.labelKey)}
            </button>
          );
        })}
      </nav>

      <button
        onClick={() => setRole(null)}
        className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-medium text-gray-400 hover:bg-gray-800 hover:text-white transition-colors"
      >
        <LogOut className="w-5 h-5" />
        {t('exit_demo')}
      </button>
    </aside>
  );
}

export function RecyclerMobileNav({ active, onNavigate }: RecyclerSidebarProps) {
  const { t, setRole } = useApp();
  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-gray-900 border-t border-gray-800 px-2 py-2">
      <div className="flex items-center justify-around">
        {items.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.key}
              onClick={() => onNavigate(item.key)}
              className={`flex flex-col items-center gap-0.5 px-2 py-1 rounded-lg ${active === item.key ? 'text-green-400' : 'text-gray-500'}`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[10px] font-semibold">{t(item.labelKey)}</span>
            </button>
          );
        })}
        <button onClick={() => setRole(null)} className="flex flex-col items-center gap-0.5 px-2 py-1 text-gray-500">
          <LogOut className="w-5 h-5" />
          <span className="text-[10px] font-semibold">{t('exit_demo')}</span>
        </button>
      </div>
    </div>
  );
}
