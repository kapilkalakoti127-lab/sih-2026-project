import { Building2, MapPin, ShieldCheck, Truck, CheckCircle2, PackageCheck } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { demoRecycler } from '@/data/mockData';

export function RecyclerProfile() {
  const { t } = useApp();
  return (
    <div className="p-5 lg:p-8 space-y-5 max-w-3xl">
      <div>
        <h1 className="text-2xl font-bold text-gray-800">{t('profile')}</h1>
        <p className="text-sm text-gray-500 mt-1">Your recycler information.</p>
      </div>
      <Card className="p-6">
        <div className="flex items-center gap-4 pb-5 border-b border-gray-100">
          <div className="w-16 h-16 rounded-2xl bg-green-100 flex items-center justify-center"><Building2 className="w-8 h-8 text-green-600" /></div>
          <div>
            <h2 className="text-xl font-bold text-gray-800">{demoRecycler.name}</h2>
            <Badge variant="success"><ShieldCheck className="w-3 h-3" /> {t('verified_authorized')}</Badge>
          </div>
        </div>
        <div className="pt-5 space-y-4 text-sm">
          <div className="flex items-center gap-3"><MapPin className="w-5 h-5 text-gray-400" /><div><p className="text-xs text-gray-400">{t('location')}</p><p className="font-semibold text-gray-800">{demoRecycler.location}</p></div></div>
          <div className="flex items-center gap-3"><PackageCheck className="w-5 h-5 text-gray-400" /><div><p className="text-xs text-gray-400">{t('materials_accepted')}</p><p className="font-semibold text-gray-800">{demoRecycler.materialsAccepted.join(', ')}</p></div></div>
          <div className="flex items-center gap-3"><Truck className="w-5 h-5 text-gray-400" /><div><p className="text-xs text-gray-400">{t('pickup_available')}</p><p className="font-semibold text-green-600">Available</p></div></div>
        </div>
      </Card>
      <Card className="bg-cyan-50 border-cyan-100"><div className="flex items-start gap-3"><CheckCircle2 className="w-5 h-5 text-cyan-600 mt-0.5" /><p className="text-sm text-cyan-800">Your facility is visible to nearby collectors looking for authorized PCB recycling.</p></div></Card>
    </div>
  );
}
