import { ArrowRight, Inbox, MapPin, Package, IndianRupee } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { demoLot } from '@/data/mockData';
import type { RecyclerScreen } from '@/types';

interface IncomingProps { onNavigate: (screen: RecyclerScreen) => void; }

export function IncomingLot({ onNavigate }: IncomingProps) {
  const { t } = useApp();
  return (
    <div className="p-5 lg:p-8 space-y-5 max-w-3xl">
      <div>
        <h1 className="text-2xl font-bold text-gray-800">{t('incoming_lot')}</h1>
        <p className="text-sm text-gray-500 mt-1">Review and respond to collector lots.</p>
      </div>

      <Card className="p-0 overflow-hidden">
        <div className="h-2 bg-green-500" />
        <div className="p-5">
          <div className="flex items-start justify-between mb-5">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-green-50 flex items-center justify-center">
                <Inbox className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-gray-800">{demoLot.lotId}</h2>
                <Badge variant="info">New Lot</Badge>
              </div>
            </div>
            <span className="text-xs text-gray-400">Today</span>
          </div>

          <div className="grid sm:grid-cols-3 gap-3 mb-5">
            <Info icon={Package} label={t('material')} value={demoLot.material} />
            <Info icon={Package} label={t('weight')} value={`${demoLot.weightKg} kg`} />
            <Info icon={MapPin} label={t('location')} value={demoLot.location} />
          </div>

          <div className="flex items-center justify-between p-3 rounded-xl bg-gray-50 mb-5">
            <span className="text-sm text-gray-500">{t('estimated_value')}</span>
            <span className="text-xl font-bold text-gray-800">₹{demoLot.estimatedValue.toLocaleString('en-IN')}</span>
          </div>

          <Button onClick={() => onNavigate('lotDetail')}>
            {t('view_lot')} <ArrowRight className="w-4 h-4 inline ml-1" />
          </Button>
        </div>
      </Card>
    </div>
  );
}

function Info({ icon: Icon, label, value }: { icon: typeof Package; label: string; value: string }) {
  return (
    <div className="p-3 rounded-xl border border-gray-100">
      <Icon className="w-4 h-4 text-gray-400 mb-2" />
      <p className="text-xs text-gray-400">{label}</p>
      <p className="font-semibold text-gray-800 mt-0.5">{value}</p>
    </div>
  );
}
