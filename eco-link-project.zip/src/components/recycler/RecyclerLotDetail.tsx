import { MapPin, Package, CheckCircle2, Truck, ShieldCheck, ChevronLeft, IndianRupee } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { demoLot, demoRecycler } from '@/data/mockData';

interface RecyclerLotDetailProps { onSendOffer: () => void; onBack: () => void; }

export function RecyclerLotDetail({ onSendOffer, onBack }: RecyclerLotDetailProps) {
  const { t } = useApp();
  return (
    <div className="p-5 lg:p-8 space-y-5 max-w-3xl">
      <button onClick={onBack} className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700">
        <ChevronLeft className="w-4 h-4" /> {t('back')}
      </button>
      <div className="flex items-center gap-3">
        <h1 className="text-2xl font-bold text-gray-800">{demoLot.lotId}</h1>
        <Badge variant="info">Incoming</Badge>
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-4">
            <Package className="w-5 h-5 text-green-600" />
            <h2 className="font-bold text-gray-800">Lot Details</h2>
          </div>
          <div className="space-y-3 text-sm">
            <Row label={t('material')} value={demoLot.material} />
            <Row label={t('weight')} value={`${demoLot.weightKg} kg`} />
            <Row label={t('location')} value={demoLot.location} icon={<MapPin className="w-3.5 h-3.5" />} />
            <Row label={t('estimated_value')} value={`₹${demoLot.estimatedValue.toLocaleString('en-IN')}`} />
          </div>
        </Card>

        <Card className="p-5 border-green-200 bg-green-50/40">
          <div className="flex items-center gap-2 mb-4">
            <IndianRupee className="w-5 h-5 text-green-600" />
            <h2 className="font-bold text-gray-800">Your Offer</h2>
          </div>
          <div className="space-y-3 text-sm">
            <Row label={t('offer')} value={`₹${demoRecycler.offeredPricePerKg}/kg`} />
            <Row label={t('total')} value="₹1,750" highlight />
            <Row label={t('pickup_available')} value="Available" icon={<Truck className="w-3.5 h-3.5" />} />
          </div>
        </Card>
      </div>

      <Card>
        <div className="flex items-center gap-3">
          <ShieldCheck className="w-5 h-5 text-green-600" />
          <div>
            <p className="font-semibold text-gray-800">Authorized material handling</p>
            <p className="text-sm text-gray-500">PCB is accepted at your Pune facility.</p>
          </div>
          <Badge variant="success" >Verified</Badge>
        </div>
      </Card>

      <div className="flex gap-3">
        <Button variant="outline" onClick={onBack}>{t('reject')}</Button>
        <Button onClick={onSendOffer}>{t('send_offer')}</Button>
      </div>
    </div>
  );
}

function Row({ label, value, icon, highlight }: { label: string; value: string; icon?: React.ReactNode; highlight?: boolean }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-gray-500">{label}</span>
      <span className={`font-semibold flex items-center gap-1 ${highlight ? 'text-green-700 text-lg' : 'text-gray-800'}`}>
        {icon}{value}
      </span>
    </div>
  );
}
