import { Inbox, CheckCircle2, Clock3, PackageCheck, ArrowRight, TrendingUp } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { demoLot, demoHandover } from '@/data/mockData';
import type { RecyclerScreen } from '@/types';

interface DashboardProps { onNavigate: (screen: RecyclerScreen) => void; }

export function RecyclerDashboard({ onNavigate }: DashboardProps) {
  const { t } = useApp();
  const stats = [
    { label: t('new_lots'), value: '1', icon: Inbox, color: 'text-cyan-600', bg: 'bg-cyan-50' },
    { label: t('accepted_today'), value: '1', icon: CheckCircle2, color: 'text-green-600', bg: 'bg-green-50' },
    { label: t('pending_pickup'), value: '0', icon: Clock3, color: 'text-amber-600', bg: 'bg-amber-50' },
    { label: t('completed'), value: '1', icon: PackageCheck, color: 'text-gray-600', bg: 'bg-gray-100' },
  ];

  return (
    <div className="p-5 lg:p-8 space-y-6 max-w-5xl">
      <div>
        <p className="text-sm text-gray-500">Welcome back</p>
        <h1 className="text-2xl font-bold text-gray-800">Recycler Dashboard</h1>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label} className="p-4">
              <div className={`w-9 h-9 rounded-lg ${stat.bg} flex items-center justify-center mb-3`}>
                <Icon className={`w-5 h-5 ${stat.color}`} />
              </div>
              <p className="text-2xl font-bold text-gray-800">{stat.value}</p>
              <p className="text-xs font-semibold text-gray-500 mt-1">{stat.label}</p>
            </Card>
          );
        })}
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        <Card className="lg:col-span-2 p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-bold text-gray-800">Incoming Lot</h2>
              <p className="text-sm text-gray-500 mt-0.5">Ready for your review</p>
            </div>
            <Badge variant="info">1 New</Badge>
          </div>
          <div className="flex items-center gap-4 p-4 rounded-xl bg-gray-50">
            <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center">
              <Inbox className="w-6 h-6 text-green-600" />
            </div>
            <div className="flex-1">
              <p className="font-bold text-gray-800">{demoLot.lotId} · {demoLot.material}</p>
              <p className="text-sm text-gray-500">{demoLot.weightKg} kg · {demoLot.location}</p>
            </div>
            <button onClick={() => onNavigate('incoming')} className="w-9 h-9 rounded-lg bg-white flex items-center justify-center hover:bg-green-50 transition-colors">
              <ArrowRight className="w-5 h-5 text-green-600" />
            </button>
          </div>
        </Card>

        <Card className="p-5 bg-green-50 border-green-100">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="w-4 h-4 text-green-600" />
            <p className="text-sm font-bold text-green-800">Today’s Activity</p>
          </div>
          <p className="text-3xl font-bold text-gray-800">₹{demoHandover.finalValue.toLocaleString('en-IN')}</p>
          <p className="text-sm text-gray-600 mt-1">Processed value</p>
          <div className="flex items-center gap-2 mt-4 text-xs text-green-700 font-semibold">
            <CheckCircle2 className="w-4 h-4" />
            1 transaction completed
          </div>
        </Card>
      </div>
    </div>
  );
}
