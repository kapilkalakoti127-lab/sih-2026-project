import { TrendingUp, TrendingDown, Minus, Volume2, Tag } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { demoPrice } from '@/data/mockData';

export function PriceBoard() {
  const { t } = useApp();

  const speak = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(new SpeechSynthesisUtterance(text));
    }
  };

  const TrendIcon =
    demoPrice.trend === 'up'
      ? TrendingUp
      : demoPrice.trend === 'down'
        ? TrendingDown
        : Minus;

  const trendColor =
    demoPrice.trend === 'up'
      ? 'text-green-600'
      : demoPrice.trend === 'down'
        ? 'text-red-500'
        : 'text-gray-400';

  return (
    <div className="px-4 py-4 space-y-4">
      <div>
        <h1 className="text-xl font-bold text-gray-800">{t('prices')}</h1>
        <Badge variant="warning">{t('sample_data')}</Badge>
      </div>

      {/* Main Price Card */}
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-10 h-10 rounded-lg bg-green-50 flex items-center justify-center">
            <Tag className="w-5 h-5 text-green-600" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-gray-800">
              {demoPrice.material}
            </h2>
            <p className="text-xs text-gray-400">{demoPrice.location}</p>
          </div>
        </div>

        <div className="flex items-center justify-between mt-4">
          <div>
            <p className="text-xs text-gray-400 font-semibold uppercase">
              {t('reference_price')}
            </p>
            <p className="text-3xl font-bold text-gray-800">
              ₹{demoPrice.referencePricePerKg}
              <span className="text-base font-semibold text-gray-400">/kg</span>
            </p>
          </div>
          <button
            onClick={() =>
              speak(
                `PCB price ${demoPrice.referencePricePerKg} rupees per kilogram in ${demoPrice.location}`
              )
            }
            className="w-11 h-11 rounded-xl bg-green-50 flex items-center justify-center hover:bg-green-100 transition-colors"
            title={t('listen_price')}
          >
            <Volume2 className="w-5 h-5 text-green-600" />
          </button>
        </div>

        <div className="flex items-center gap-1.5 mt-3">
          <TrendIcon className={`w-4 h-4 ${trendColor}`} />
          <span className={`text-sm font-semibold ${trendColor}`}>
            {demoPrice.trend === 'up' ? '+' : demoPrice.trend === 'down' ? '-' : ''}
            {demoPrice.trendPercent}% this week
          </span>
        </div>
      </Card>

      {/* Market Range */}
      <Card>
        <p className="text-xs font-semibold text-gray-400 uppercase mb-3">
          {t('market_range')}
        </p>
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-gray-500">
            ₹{demoPrice.minPricePerKg}/kg
          </span>
          <span className="text-sm text-gray-500">
            ₹{demoPrice.maxPricePerKg}/kg
          </span>
        </div>
        <div className="relative h-3 rounded-full bg-gray-100">
          <div className="absolute h-3 rounded-full bg-gradient-to-r from-green-300 to-green-500 left-[25%] right-[25%]" />
          <div className="absolute top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-green-600 border-2 border-white shadow" />
        </div>
        <p className="text-center text-xs text-green-600 font-semibold mt-2">
          ₹{demoPrice.referencePricePerKg}/kg (current)
        </p>
      </Card>
    </div>
  );
}
