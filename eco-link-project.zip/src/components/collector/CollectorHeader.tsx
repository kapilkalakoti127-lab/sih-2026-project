import { Recycle, Wifi, WifiOff, Globe, X } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import type { Language } from '@/types';

export function CollectorHeader() {
  const { t, online, setOnline, language, setLanguage } = useApp();

  const cycleLanguage = () => {
    const order: Language[] = ['en', 'hi', 'mr'];
    const idx = order.indexOf(language);
    setLanguage(order[(idx + 1) % order.length]);
  };

  const langLabel: Record<Language, string> = {
    en: 'EN',
    hi: 'हि',
    mr: 'मर',
  };

  return (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-sm border-b border-gray-100 px-4 py-3">
      <div className="flex items-center justify-between max-w-md mx-auto">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-lg bg-green-600 flex items-center justify-center">
            <Recycle className="w-5 h-5 text-white" strokeWidth={2.5} />
          </div>
          <span className="font-bold text-gray-800 text-lg">
            {t('app_name')}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={cycleLanguage}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-gray-100 hover:bg-gray-200 transition-colors text-sm font-semibold text-gray-600"
          >
            <Globe className="w-4 h-4" />
            {langLabel[language]}
          </button>
          <button
            onClick={() => setOnline(!online)}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-sm font-semibold transition-colors ${
              online
                ? 'bg-green-50 text-green-600 hover:bg-green-100'
                : 'bg-amber-50 text-amber-600 hover:bg-amber-100'
            }`}
          >
            {online ? (
              <>
                <Wifi className="w-4 h-4" />
                {t('online')}
              </>
            ) : (
              <>
                <WifiOff className="w-4 h-4" />
                {t('offline')}
              </>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}

export function CollectorExitBar() {
  const { setRole } = useApp();
  return (
    <button
      onClick={() => setRole(null)}
      className="fixed top-2 right-2 z-50 w-8 h-8 rounded-full bg-gray-200/80 flex items-center justify-center text-gray-500 hover:bg-gray-300 transition-colors"
      title="Exit demo"
    >
      <X className="w-4 h-4" />
    </button>
  );
}
