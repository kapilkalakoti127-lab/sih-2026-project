import {
  MapPin,
  CheckCircle2,
  Truck,
  Star,
  ChevronLeft,
  ShieldCheck,
} from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { demoRecycler } from '@/data/mockData';

interface RecyclerMatchProps {
  onViewOffer: () => void;
  onBack: () => void;
}

export function RecyclerMatch({ onViewOffer, onBack }: RecyclerMatchProps) {
  const { t } = useApp();

  const matchReasons = [
    { icon: CheckCircle2, label: `${demoRecycler.materialsAccepted.join(', ')} accepted` },
    { icon: Star, label: `Good price: ₹${demoRecycler.offeredPricePerKg}/kg` },
    { icon: MapPin, label: `Nearby: ${demoRecycler.location}` },
    { icon: Truck, label: t('pickup_available') },
    { icon: ShieldCheck, label: t('verified_authorized') },
  ];

  return (
    <div className="px-4 py-4 space-y-4">
      <button
        onClick={onBack}
        className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700 transition-colors"
      >
        <ChevronLeft className="w-4 h-4" />
        {t('back')}
      </button>

      <h1 className="text-xl font-bold text-gray-800">{t('find_recycler')}</h1>

      {/* Match Score Badge */}
      <div className="flex items-center justify-center">
        <div className="relative">
          <div className="w-20 h-20 rounded-full bg-green-50 flex items-center justify-center">
            <span className="text-2xl font-bold text-green-600">
              {demoRecycler.matchScore}
            </span>
          </div>
          <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 text-[10px] font-bold text-gray-400 uppercase whitespace-nowrap">
            {t('match_score')}
          </div>
        </div>
      </div>

      {/* Recycler Card */}
      <Card className="p-5">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center">
            <ShieldCheck className="w-6 h-6 text-green-600" />
          </div>
          <div className="flex-1">
            <h2 className="text-lg font-bold text-gray-800">
              {demoRecycler.name}
            </h2>
            <div className="flex items-center gap-2 mt-0.5">
              <Badge variant="success">
                <CheckCircle2 className="w-3 h-3" />
                {t('verified_authorized')}
              </Badge>
            </div>
          </div>
        </div>

        <div className="space-y-2.5 text-sm">
          <div className="flex items-center gap-2 text-gray-600">
            <MapPin className="w-4 h-4 text-gray-400" />
            {demoRecycler.location}
          </div>
          <div className="flex items-center gap-2 text-gray-600">
            <Star className="w-4 h-4 text-gray-400" />
            ₹{demoRecycler.offeredPricePerKg}/kg offer
          </div>
          <div className="flex items-center gap-2 text-gray-600">
            <Truck className="w-4 h-4 text-gray-400" />
            {t('pickup_available')}
          </div>
        </div>
      </Card>

      {/* Why Matched */}
      <Card>
        <p className="text-sm font-semibold text-gray-700 mb-3">
          {t('why_matched')}
        </p>
        <div className="space-y-2">
          {matchReasons.map((reason, i) => {
            const Icon = reason.icon;
            return (
              <div key={i} className="flex items-center gap-2.5 text-sm text-gray-600">
                <div className="w-7 h-7 rounded-lg bg-green-50 flex items-center justify-center shrink-0">
                  <Icon className="w-4 h-4 text-green-600" />
                </div>
                {reason.label}
              </div>
            );
          })}
        </div>
      </Card>

      <Button fullWidth size="lg" onClick={onViewOffer}>
        {t('view_offer')}
      </Button>
    </div>
  );
}
