import { Wallet, ArrowDownLeft, CheckCircle2, TrendingUp } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { demoEarnings } from '@/data/mockData';

export function Earnings() {
  const { t } = useApp();

  return (
    <div className="px-4 py-4 space-y-4">
      <h1 className="text-xl font-bold text-gray-800">{t('earnings')}</h1>

      {/* Total */}
      <Card className="bg-green-600 border-green-600 p-5">
        <div className="flex items-center gap-2 text-green-100 mb-2">
          <Wallet className="w-5 h-5" />
          <span className="text-sm font-semibold">{t('total_earnings')}</span>
        </div>
        <p className="text-4xl font-bold text-white">
          ₹{demoEarnings.totalEarnings.toLocaleString('en-IN')}
        </p>
        <div className="flex items-center gap-1.5 mt-3 text-green-100 text-sm">
          <TrendingUp className="w-4 h-4" />
          Better price through ECO-LINK
        </div>
      </Card>

      {/* Paid / Pending */}
      <div className="grid grid-cols-2 gap-3">
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-lg bg-green-100 flex items-center justify-center">
              <ArrowDownLeft className="w-4 h-4 text-green-600" />
            </div>
            <span className="text-sm text-gray-500">{t('paid')}</span>
          </div>
          <p className="text-xl font-bold text-gray-800">
            ₹{demoEarnings.paid.toLocaleString('en-IN')}
          </p>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center">
              <Wallet className="w-4 h-4 text-gray-400" />
            </div>
            <span className="text-sm text-gray-500">{t('pending')}</span>
          </div>
          <p className="text-xl font-bold text-gray-800">
            ₹{demoEarnings.pending.toLocaleString('en-IN')}
          </p>
        </Card>
      </div>

      {/* Transaction History */}
      <div>
        <h2 className="text-sm font-bold text-gray-700 mb-2">
          {t('transaction_history')}
        </h2>
        {demoEarnings.transactions.map((transaction) => (
          <Card key={transaction.lotId} className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-green-50 flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              </div>
              <div className="flex-1">
                <p className="font-bold text-gray-800">
                  {transaction.lotId} — {transaction.material}
                </p>
                <p className="text-xs text-gray-400 mt-0.5">{transaction.date}</p>
              </div>
              <div className="text-right">
                <p className="font-bold text-gray-800">
                  ₹{transaction.amount.toLocaleString('en-IN')}
                </p>
                <Badge variant="success">{transaction.paymentStatus}</Badge>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
