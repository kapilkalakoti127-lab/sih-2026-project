import { ChevronLeft, CheckCircle2, MapPin, Calendar, QrCode, Link2, TrendingUp } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { demoLot, demoHandover, traceabilityEvents } from '@/data/mockData';

interface LotDetailProps {
  onBack: () => void;
}

export function LotDetail({ onBack }: LotDetailProps) {
  const { t } = useApp();

  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="px-4 py-4 space-y-4">
      <button
        onClick={onBack}
        className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700 transition-colors"
      >
        <ChevronLeft className="w-4 h-4" />
        {t('back')}
      </button>

      <div className="flex items-center gap-2">
        <h1 className="text-xl font-bold text-gray-800">{demoLot.lotId}</h1>
        <Badge variant="success">
          <CheckCircle2 className="w-3 h-3" />
          {demoLot.status}
        </Badge>
      </div>

      {/* Lot Details */}
      <Card>
        <div className="space-y-2.5 text-sm">
          <Row label={t('material')} value={demoLot.material} />
          <Row label={t('weight')} value={`${demoLot.weightKg} kg`} />
          <Row label={t('location')} value={demoLot.location} />
          <Row label={t('reference_price')} value={`₹${demoLot.referencePricePerKg}/kg`} />
          <Row label={t('estimated_value')} value={`₹${demoLot.estimatedValue.toLocaleString('en-IN')}`} />
          <Row label={t('final_value')} value={`₹${demoHandover.finalValue.toLocaleString('en-IN')}`} highlight />
          <div className="flex justify-between items-center">
            <span className="text-gray-500">{t('payment_status')}</span>
            <Badge variant="success">{demoHandover.paymentStatus}</Badge>
          </div>
        </div>
      </Card>

      {/* Handover Reference */}
      <Card className="flex items-center gap-4">
        <div className="w-16 h-16 rounded-xl bg-gray-50 border-2 border-gray-200 flex items-center justify-center">
          <QrCode className="w-9 h-9 text-gray-300" />
        </div>
        <div>
          <p className="text-xs font-semibold text-gray-400 uppercase">{t('handover_ref')}</p>
          <p className="font-bold text-gray-800 text-sm">{demoHandover.handoverRef}</p>
          <p className="text-xs text-gray-400 mt-0.5">{formatDate(demoHandover.dateTime)}</p>
        </div>
      </Card>

      {/* Unit Economics */}
      <Card className="bg-cyan-50 border-cyan-100">
        <div className="flex items-center gap-2 mb-3">
          <TrendingUp className="w-4 h-4 text-cyan-600" />
          <p className="text-sm font-semibold text-cyan-800">{t('unit_economics')}</p>
        </div>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-500">{t('existing_value')}</span>
            <span className="font-semibold text-gray-700">₹1,600</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-500">{t('platform_offer')}</span>
            <span className="font-semibold text-gray-700">₹1,750</span>
          </div>
          <div className="flex justify-between pt-2 border-t border-cyan-200">
            <span className="text-cyan-700 font-medium">{t('additional_earning')}</span>
            <span className="font-bold text-green-600">+₹150</span>
          </div>
        </div>
        <p className="text-[10px] text-gray-400 mt-2 italic">{t('illustrative_data')}</p>
      </Card>

      {/* Traceability Timeline */}
      <Card>
        <div className="flex items-center gap-2 mb-4">
          <Link2 className="w-4 h-4 text-green-600" />
          <p className="text-sm font-semibold text-gray-700">{t('traceability')}</p>
        </div>
        <div className="space-y-0">
          {traceabilityEvents.map((event, i) => (
            <div key={event.step} className="flex gap-3">
              <div className="flex flex-col items-center">
                <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 bg-green-600 text-white">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                {i < traceabilityEvents.length - 1 && (
                  <div className="w-0.5 h-6 bg-green-200" />
                )}
              </div>
              <p className="text-sm pt-1 text-gray-700 font-medium">{event.label}</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function Row({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-gray-500">{label}</span>
      <span className={`font-semibold ${highlight ? 'text-green-700 text-lg' : 'text-gray-800'}`}>{value}</span>
    </div>
  );
}
