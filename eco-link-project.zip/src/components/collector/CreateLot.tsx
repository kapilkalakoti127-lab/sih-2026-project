import { useState } from 'react';
import {
  Camera,
  Check,
  ChevronLeft,
  Image as ImageIcon,
  Sparkles,
  Scale,
} from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { MATERIAL_CATEGORIES, DEMO_PHOTO_URL } from '@/data/mockData';
import type { CollectorScreen, MaterialCategory } from '@/types';

interface CreateLotProps {
  onComplete: (material: MaterialCategory, weightKg: number) => void;
  onBack: () => void;
}

export function CreateLot({ onComplete, onBack }: CreateLotProps) {
  const { t } = useApp();
  const [step, setStep] = useState(1);
  const [photoTaken, setPhotoTaken] = useState(false);
  const [selectedMaterial, setSelectedMaterial] =
    useState<MaterialCategory | null>(null);

  const materialIcons: Record<MaterialCategory, string> = {
    PCB: '🔌',
    Cable: '🔗',
    Battery: '🔋',
    LCD: '🖥️',
    Motor: '⚙️',
    'Mixed Plastic': '🧴',
  };

  return (
    <div className="px-4 py-4 space-y-4">
      {/* Back + Step indicator */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => (step === 1 ? onBack() : setStep(step - 1))}
          className="w-9 h-9 rounded-lg bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition-colors"
        >
          <ChevronLeft className="w-5 h-5 text-gray-600" />
        </button>
        <div className="flex-1">
          <div className="flex items-center gap-1.5">
            {[1, 2, 3].map((s) => (
              <div
                key={s}
                className={`h-1.5 flex-1 rounded-full transition-colors ${
                  s <= step ? 'bg-green-600' : 'bg-gray-200'
                }`}
              />
            ))}
          </div>
          <p className="text-xs text-gray-400 mt-1">
            {t('step')} {step} {t('of')} 3 —{' '}
            {step === 1 ? t('photograph') : step === 2 ? t('categorize') : t('weight')}
          </p>
        </div>
      </div>

      {/* Step 1 — Photograph */}
      {step === 1 && (
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-gray-800">{t('photograph')}</h2>
          <button
            onClick={() => setPhotoTaken(true)}
            className="w-full aspect-square max-h-72 rounded-2xl border-2 border-dashed border-green-300 bg-green-50 flex flex-col items-center justify-center gap-3 hover:bg-green-100 transition-colors overflow-hidden relative"
          >
            {photoTaken ? (
              <>
                <img
                  src={DEMO_PHOTO_URL}
                  alt="E-waste"
                  className="absolute inset-0 w-full h-full object-cover"
                />
                <div className="absolute bottom-3 right-3 w-8 h-8 rounded-full bg-green-600 flex items-center justify-center">
                  <Check className="w-5 h-5 text-white" />
                </div>
              </>
            ) : (
              <>
                <Camera className="w-12 h-12 text-green-400" strokeWidth={1.5} />
                <p className="text-sm text-green-600 font-medium text-center px-4">
                  {t('camera_area')}
                </p>
              </>
            )}
          </button>
          {photoTaken && (
            <p className="text-xs text-gray-400 flex items-center gap-1 justify-center">
              <ImageIcon className="w-3 h-3" />
              {t('example_photo')}
            </p>
          )}
          <Button
            fullWidth
            size="lg"
            disabled={!photoTaken}
            onClick={() => setStep(2)}
          >
            {t('continue')}
          </Button>
        </div>
      )}

      {/* Step 2 — Categorize */}
      {step === 2 && (
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-gray-800">{t('select_material')}</h2>
          <div className="grid grid-cols-2 gap-3">
            {MATERIAL_CATEGORIES.map((mat) => {
              const isSelected = selectedMaterial === mat;
              return (
                <button
                  key={mat}
                  onClick={() => setSelectedMaterial(mat)}
                  className={`rounded-2xl p-4 border-2 transition-all duration-150 active:scale-[0.98] ${
                    isSelected
                      ? 'border-green-600 bg-green-50'
                      : 'border-gray-100 bg-white hover:border-gray-200'
                  }`}
                >
                  <div className="text-3xl mb-2">{materialIcons[mat]}</div>
                  <p
                    className={`font-semibold text-sm ${isSelected ? 'text-green-700' : 'text-gray-600'}`}
                  >
                    {mat}
                  </p>
                </button>
              );
            })}
          </div>

          {selectedMaterial && (
            <Card className="bg-cyan-50 border-cyan-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-cyan-100 flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-cyan-600" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-cyan-800">
                    {t('ai_suggestion')}
                  </p>
                </div>
              </div>
            </Card>
          )}

          <Button
            fullWidth
            size="lg"
            disabled={!selectedMaterial}
            onClick={() => setStep(3)}
          >
            {t('confirm_material')}
          </Button>
        </div>
      )}

      {/* Step 3 — Weight */}
      {step === 3 && (
        <div className="space-y-5">
          <h2 className="text-xl font-bold text-gray-800">{t('weight')}</h2>

          <Card className="p-5 text-center">
            <Scale className="w-10 h-10 text-green-500 mx-auto mb-3" />
            <div className="flex items-center justify-center gap-1">
              <span className="text-5xl font-bold text-gray-800">5</span>
              <span className="text-2xl font-semibold text-gray-400 ml-1">kg</span>
            </div>
          </Card>

          <Card className="bg-green-50 border-green-100">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-gray-600">
                {t('reference_price')}
              </span>
              <span className="text-lg font-bold text-green-700">
                ₹320/kg
              </span>
            </div>
          </Card>

          <Card className="bg-green-600 border-green-600">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-green-50">
                {t('estimated_value')}
              </span>
              <span className="text-2xl font-bold text-white">
                ₹1,600
              </span>
            </div>
          </Card>

          <Button
            fullWidth
            size="lg"
            onClick={() =>
              onComplete(selectedMaterial || 'PCB', 5)
            }
          >
            {t('find_recycler')}
          </Button>
        </div>
      )}
    </div>
  );
}
