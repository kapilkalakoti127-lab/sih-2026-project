import {
  Camera,
  Tag,
  Wallet,
  Package,
  ShieldAlert,
  Volume2,
  ArrowRight,
  CheckCircle2,
} from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { demoEarnings, demoLot } from '@/data/mockData';
import type { CollectorScreen } from '@/types';

interface HomeProps {
  onNavigate: (screen: CollectorScreen) => void;
}

export function CollectorHome({ onNavigate }: HomeProps) {
  const { t, online } = useApp();

  const speak = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(new SpeechSynthesisUtterance(text));
    }
  };

  return (
    <div className="px-4 py-4 space-y-4">
      {/* Greeting */}
      <div>
        <h1 className="text-2xl font-bold text-gray-800">{t('namaste')} 👋</h1>
        <p className="text-gray-500 mt-1">{t('tagline')}</p>
      </div>

      {/* Sell E-Waste CTA */}
      <button
        onClick={() => onNavigate('create')}
        className="w-full bg-gradient-to-r from-green-600 to-green-500 rounded-2xl p-5 shadow-md hover:shadow-lg transition-all duration-200 active:scale-[0.98] text-left"
      >
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center">
            <Camera className="w-7 h-7 text-white" strokeWidth={2.5} />
          </div>
          <div className="flex-1">
            <h2 className="text-xl font-bold text-white">{t('sell_ewaste')}</h2>
            <p className="text-green-50 text-sm">Get fair price in 3 steps</p>
          </div>
          <ArrowRight className="w-6 h-6 text-white" />
        </div>
      </button>

      {/* Today's Earnings */}
      <div className="grid grid-cols-2 gap-3">
        <Card className="p-3.5">
          <div className="flex items-center gap-2 mb-1">
            <Wallet className="w-4 h-4 text-green-600" />
            <span className="text-xs font-semibold text-gray-500 uppercase">
              {t('todays_earnings')}
            </span>
          </div>
          <p className="text-xl font-bold text-gray-800">
            ₹{demoEarnings.totalEarnings.toLocaleString('en-IN')}
          </p>
        </Card>
        <Card
          className="p-3.5"
          onClick={() => onNavigate('mylot')}
        >
          <div className="flex items-center gap-2 mb-1">
            <Package className="w-4 h-4 text-cyan-600" />
            <span className="text-xs font-semibold text-gray-500 uppercase">
              {t('recent_lot')}
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-xl font-bold text-gray-800">EW-001</span>
            <Badge variant="success">
              <CheckCircle2 className="w-3 h-3" />
            </Badge>
          </div>
        </Card>
      </div>

      {/* Active Lot */}
      <Card onClick={() => onNavigate('lotDetail')}>
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-gray-400 uppercase">
            {t('active_lot')}
          </span>
          <Badge variant="success">{demoLot.status}</Badge>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-lg bg-green-50 flex items-center justify-center">
            <Package className="w-6 h-6 text-green-600" />
          </div>
          <div className="flex-1">
            <p className="font-bold text-gray-800">
              {demoLot.lotId} — {demoLot.material}
            </p>
            <p className="text-sm text-gray-500">
              {demoLot.weightKg} kg · ₹1,750
            </p>
          </div>
          <ArrowRight className="w-5 h-5 text-gray-300" />
        </div>
      </Card>

      {/* Safety Reminder */}
      <Card className="bg-amber-50 border-amber-100">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center shrink-0">
            <ShieldAlert className="w-5 h-5 text-amber-600" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-semibold text-amber-800 mb-0.5">
              {t('safety_reminder')}
            </p>
          </div>
          <button
            onClick={() => speak(t('safety_reminder'))}
            className="w-9 h-9 rounded-lg bg-amber-100 flex items-center justify-center shrink-0 hover:bg-amber-200 transition-colors"
          >
            <Volume2 className="w-4 h-4 text-amber-700" />
          </button>
        </div>
      </Card>

      {/* Offline notice */}
      {!online && (
        <Card className="bg-amber-50 border-amber-200">
          <p className="text-sm text-amber-700 font-medium">
            {t('offline_msg')}
          </p>
        </Card>
      )}
    </div>
  );
}
