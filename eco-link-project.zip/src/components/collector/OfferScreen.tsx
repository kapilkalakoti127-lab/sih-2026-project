import { ChevronLeft, CheckCircle2, Truck, ShieldCheck } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { demoLot, demoRecycler } from '@/data/mockData';

interface OfferProps {
  onAccept: () => void;
  onDecline: () => void;
  onBack: () => void;
}

export function OfferScreen({ onAccept, onDecline, onBack }: OfferProps) {
  const { t } = useApp();

  return (
    <div className="px-4 py-4 space-y-4">
      <button
        onClick={onBack}
        className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700 transition-colors"
      >
        <ChevronLeft className="w-4 h-4" />
        {t('back')}
      </button>

      <h1 className="text-xl font-bold text-gray-800">{t('recycler_offer')}</h1>

      {/* Your Lot */}
      <Card>
        <p className="text-xs font-semibold text-gray-400 uppercase mb-3">
          {t('your_lot')}
        </p>
        <div className="space-y-2.5 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-500">{t('lot_id')}</span>
            <span className="font-semibold text-gray-800">{demoLot.lotId}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-500">{t('material')}</span>
            <span className="font-semibold text-gray-800">{demoLot.material}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-500">{t('weight')}</span>
            <span className="font-semibold text-gray-800">{demoLot.weightKg} kg</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-500">{t('reference_price')}</span>
            <span className="font-semibold text-gray-800">
              ₹{demoLot.referencePricePerKg}/kg
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-500">{t('estimated_value')}</span>
            <span className="font-semibold text-gray-800">
              ₹{demoLot.estimatedValue.toLocaleString('en-IN')}
            </span>
          </div>
        </div>
      </Card>

      {/* Recycler Offer */}
      <Card className="border-green-200 bg-green-50/50">
        <div className="flex items-center gap-2 mb-3">
          <ShieldCheck className="w-5 h-5 text-green-600" />
          <p className="text-xs font-semibold text-green-700 uppercase">
            {t('recycler_offer')}
          </p>
        </div>
        <h2 className="text-lg font-bold text-gray-800 mb-3">
          {demoRecycler.name}
        </h2>
        <div className="space-y-2.5 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-500">{t('offer')}</span>
            <span className="font-semibold text-gray-800">
              ₹{demoRecycler.offeredPricePerKg}/kg
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-500">{t('total')}</span>
            <span className="text-xl font-bold text-green-700">
              ₹{demoOffer_total().toLocaleString('en-IN')}
            </span>
          </div>
          <div className="flex items-center gap-1.5 text-sm text-gray-600">
            <Truck className="w-4 h-4 text-green-500" />
            {t('pickup_available')}
          </div>
        </div>
      </Card>

      {/* Extra earning highlight */}
      <Card className="bg-cyan-50 border-cyan-100">
        <div className="flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-cyan-600" />
          <p className="text-sm text-cyan-800 font-medium">
            You earn ₹150 more than the reference price!
          </p>
        </div>
      </Card>

      <div className="flex gap-3">
        <Button variant="outline" size="lg" fullWidth onClick={onDecline}>
          {t('decline')}
        </Button>
        <Button size="lg" fullWidth onClick={onAccept}>
          {t('accept_offer')}
        </Button>
      </div>
    </div>
  );
}

function demoOffer_total() {
  return demoRecycler.offeredPricePerKg * 5;
}
