import { Package, ChevronRight, CheckCircle2 } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { demoLot } from '@/data/mockData';
import type { CollectorScreen } from '@/types';

interface MyLotProps {
  onNavigate: (screen: CollectorScreen) => void;
}

export function MyLot({ onNavigate }: MyLotProps) {
  const { t } = useApp();

  return (
    <div className="px-4 py-4 space-y-4">
      <h1 className="text-xl font-bold text-gray-800">{t('my_lot')}</h1>

      <Card
        onClick={() => onNavigate('lotDetail')}
        className="p-4"
      >
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-green-50 flex items-center justify-center">
            <Package className="w-6 h-6 text-green-600" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h2 className="font-bold text-gray-800">{demoLot.lotId}</h2>
              <Badge variant="success">
                <CheckCircle2 className="w-3 h-3" />
                {demoLot.status}
              </Badge>
            </div>
            <p className="text-sm text-gray-500 mt-0.5">
              {demoLot.material} · {demoLot.weightKg} kg · ₹1,750
            </p>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-300" />
        </div>
      </Card>
    </div>
  );
}
