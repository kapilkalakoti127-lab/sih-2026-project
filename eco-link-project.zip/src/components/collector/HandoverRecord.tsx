import {
  CheckCircle2,
  MapPin,
  Calendar,
  QrCode,
  ShieldCheck,
  Link2,
} from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { demoHandover, traceabilityEvents } from '@/data/mockData';

interface HandoverProps {
  onDone: () => void;
}

export function HandoverRecord({ onDone }: HandoverProps) {
  const { t } = useApp();

  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="px-4 py-4 space-y-4">
      {/* Success Banner */}
      <div className="flex flex-col items-center text-center pt-2 pb-1">
        <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-3 animate-pulse">
          <CheckCircle2 className="w-9 h-9 text-green-600" strokeWidth={2.5} />
        </div>
        <h1 className="text-xl font-bold text-gray-800">
          {t('handover_confirmed')}
        </h1>
        <p className="text-sm text-gray-500 mt-1">
          Lot {demoHandover.lotId} successfully handed over
        </p>
      </div>

      {/* Handover Details */}
      <Card>
        <div className="space-y-3 text-sm">
          <Row label={t('lot_id')} value={demoHandover.lotId} />
          <Row label={t('material')} value={demoHandover.material} />
          <Row label={t('weight')} value={`${demoHandover.weightKg} kg`} />
          <Row label={t('recycler')} value={demoHandover.recyclerName} />
          <div className="flex justify-between items-center">
            <span className="text-gray-500">{t('location')}</span>
            <span className="font-semibold text-gray-800 flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-gray-400" />
              {demoHandover.location}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-500">{t('date_time')}</span>
            <span className="font-semibold text-gray-800 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-gray-400" />
              {formatDate(demoHandover.dateTime)}
            </span>
          </div>
          <Row
            label={t('final_value')}
            value={`₹${demoHandover.finalValue.toLocaleString('en-IN')}`}
            highlight
          />
          <div className="flex justify-between items-center">
            <span className="text-gray-500">{t('payment_status')}</span>
            <Badge variant="success">{demoHandover.paymentStatus}</Badge>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-500">{t('recycler_confirmation')}</span>
            <Badge variant="success">
              <CheckCircle2 className="w-3 h-3" />
              {t('confirmed')}
            </Badge>
          </div>
        </div>
      </Card>

      {/* Handover Reference + QR */}
      <Card className="flex items-center gap-4">
        <div className="w-20 h-20 rounded-xl bg-gray-50 border-2 border-gray-200 flex items-center justify-center">
          <QrCode className="w-12 h-12 text-gray-300" />
        </div>
        <div>
          <p className="text-xs font-semibold text-gray-400 uppercase">
            {t('handover_ref')}
          </p>
          <p className="font-bold text-gray-800 text-sm">
            {demoHandover.handoverRef}
          </p>
        </div>
      </Card>

      {/* Traceability Timeline */}
      <Card>
        <div className="flex items-center gap-2 mb-4">
          <Link2 className="w-4 h-4 text-green-600" />
          <p className="text-sm font-semibold text-gray-700">
            {t('traceability')}
          </p>
        </div>
        <div className="space-y-0">
          {traceabilityEvents.map((event, i) => (
            <div key={event.step} className="flex gap-3">
              <div className="flex flex-col items-center">
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                    event.completed
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-200 text-gray-400'
                  }`}
                >
                  {event.completed ? (
                    <CheckCircle2 className="w-4 h-4" />
                  ) : (
                    event.step
                  )}
                </div>
                {i < traceabilityEvents.length - 1 && (
                  <div className="w-0.5 h-6 bg-green-200" />
                )}
              </div>
              <p
                className={`text-sm pt-1 ${event.completed ? 'text-gray-700 font-medium' : 'text-gray-400'}`}
              >
                {event.label}
              </p>
            </div>
          ))}
        </div>
      </Card>

      <Button fullWidth size="lg" onClick={onDone}>
        {t('earnings')}
      </Button>
    </div>
  );
}

function Row({
  label,
  value,
  highlight,
}: {
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-gray-500">{label}</span>
      <span
        className={`font-semibold ${highlight ? 'text-green-700 text-lg' : 'text-gray-800'}`}
      >
        {value}
      </span>
    </div>
  );
}
