import type {
  MaterialLot,
  Price,
  Recycler,
  Offer,
  HandoverRecord,
  Earnings,
  TraceabilityEvent,
} from '@/types';

export const DEMO_PHOTO_URL =
  'https://images.pexels.com/photos/163125/board-printed-circuit-board-computer-electronics-163125.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

export const MATERIAL_CATEGORIES = [
  'PCB',
  'Cable',
  'Battery',
  'LCD',
  'Motor',
  'Mixed Plastic',
] as const;

export const demoLot: MaterialLot = {
  lotId: 'EW-001',
  material: 'PCB',
  weightKg: 5,
  photoUrl: DEMO_PHOTO_URL,
  location: 'Pune',
  createdAt: '2026-09-08T10:30:00',
  status: 'Completed',
  referencePricePerKg: 320,
  estimatedValue: 1600,
};

export const demoPrice: Price = {
  material: 'PCB',
  referencePricePerKg: 320,
  minPricePerKg: 300,
  maxPricePerKg: 340,
  location: 'Pune',
  trend: 'up',
  trendPercent: 3,
};

export const demoRecycler: Recycler = {
  id: 'REC-001',
  name: 'GreenCycle Recycler',
  authorized: true,
  location: 'Pune',
  materialsAccepted: ['PCB'],
  offeredPricePerKg: 350,
  pickupAvailable: true,
  matchScore: 92,
};

export const demoOffer: Offer = {
  lotId: 'EW-001',
  recycler: demoRecycler,
  offeredPricePerKg: 350,
  totalValue: 1750,
  pickupAvailable: true,
  status: 'accepted',
};

export const demoHandover: HandoverRecord = {
  lotId: 'EW-001',
  material: 'PCB',
  weightKg: 5,
  recyclerName: 'GreenCycle Recycler',
  location: 'Pune',
  dateTime: '2026-09-08T14:45:00',
  finalValue: 1750,
  paymentStatus: 'Paid',
  handoverRef: 'HOF-PUN-2026-00123',
  confirmed: true,
};

export const demoEarnings: Earnings = {
  totalEarnings: 1750,
  paid: 1750,
  pending: 0,
  transactions: [
    {
      lotId: 'EW-001',
      material: 'PCB',
      amount: 1750,
      paymentStatus: 'Paid',
      date: '2026-09-08',
    },
  ],
};

export const traceabilityEvents: TraceabilityEvent[] = [
  { step: '1', label: 'Collector creates lot', completed: true },
  { step: '2', label: 'PCB identified', completed: true },
  { step: '3', label: 'Weight recorded', completed: true },
  { step: '4', label: 'Price estimated', completed: true },
  { step: '5', label: 'Recycler matched', completed: true },
  { step: '6', label: 'Offer accepted', completed: true },
  { step: '7', label: 'Handover confirmed', completed: true },
  { step: '8', label: 'Payment recorded', completed: true },
];
