import {
  createContext,
  useContext,
  useState,
  type ReactNode,
} from 'react';
import type { Language, Role } from '@/types';
import { translate } from '@/i18n/translations';

interface AppState {
  role: Role;
  setRole: (r: Role) => void;
  language: Language;
  setLanguage: (l: Language) => void;
  online: boolean;
  setOnline: (o: boolean) => void;
  t: (key: string) => string;
}

const AppContext = createContext<AppState | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [role, setRole] = useState<Role>(null);
  const [language, setLanguage] = useState<Language>('en');
  const [online, setOnline] = useState<boolean>(true);

  const t = (key: string) => translate(key, language);

  return (
    <AppContext.Provider
      value={{ role, setRole, language, setLanguage, online, setOnline, t }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
