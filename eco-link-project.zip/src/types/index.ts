export type MaterialCategory =
  | 'PCB'
  | 'Cable'
  | 'Battery'
  | 'LCD'
  | 'Motor'
  | 'Mixed Plastic';

export type LotStatus =
  | 'Created'
  | 'Priced'
  | 'Matched'
  | 'Offered'
  | 'Accepted'
  | 'HandedOver'
  | 'Completed';

export type PaymentStatus = 'Pending' | 'Paid';

export type Language = 'en' | 'hi' | 'mr';

export type Role = 'collector' | 'recycler' | null;

export interface MaterialLot {
  lotId: string;
  material: MaterialCategory;
  weightKg: number;
  photoUrl: string;
  location: string;
  createdAt: string;
  status: LotStatus;
  referencePricePerKg: number;
  estimatedValue: number;
}

export interface Price {
  material: MaterialCategory;
  referencePricePerKg: number;
  minPricePerKg: number;
  maxPricePerKg: number;
  location: string;
  trend: 'up' | 'down' | 'stable';
  trendPercent: number;
}

export interface Recycler {
  id: string;
  name: string;
  authorized: boolean;
  location: string;
  materialsAccepted: MaterialCategory[];
  offeredPricePerKg: number;
  pickupAvailable: boolean;
  matchScore: number;
}

export interface Offer {
  lotId: string;
  recycler: Recycler;
  offeredPricePerKg: number;
  totalValue: number;
  pickupAvailable: boolean;
  status: 'pending' | 'accepted' | 'declined';
}

export interface HandoverRecord {
  lotId: string;
  material: MaterialCategory;
  weightKg: number;
  recyclerName: string;
  location: string;
  dateTime: string;
  finalValue: number;
  paymentStatus: PaymentStatus;
  handoverRef: string;
  confirmed: boolean;
}

export interface Transaction {
  lotId: string;
  material: MaterialCategory;
  amount: number;
  paymentStatus: PaymentStatus;
  date: string;
}

export interface Earnings {
  totalEarnings: number;
  paid: number;
  pending: number;
  transactions: Transaction[];
}

export interface TraceabilityEvent {
  step: string;
  label: string;
  completed: boolean;
}

export type CollectorScreen =
  | 'home'
  | 'create'
  | 'match'
  | 'offer'
  | 'handover'
  | 'lotDetail'
  | 'mylot'
  | 'prices'
  | 'earnings';

export type RecyclerScreen =
  | 'dashboard'
  | 'incoming'
  | 'lotDetail'
  | 'transactions'
  | 'profile';
